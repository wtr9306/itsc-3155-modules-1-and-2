n = int(input("Enter an integer greater than 1: "))

for i in range(n+1):
    print(i**3)
