user_string = input("Enter a string: ")
characters = list(user_string)

result = [characters[n:n+3] for n in range(0, len(characters), 3)]

print("Original string: ", user_string)
print("List of lists: ", result)
