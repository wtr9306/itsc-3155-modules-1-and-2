string1 = input("Enter first string: ")
string2 = input("Enter second string: ")

if string1.endswith(string2) or string2.endswith(string1):
    print("True")
else:
    print("False")
