words = []
for i in range(5):
    word = input(f"Enter word {i+1}: ")
    words.append(word)

resultant_string = " ".join(words)

print("The list of words: ", words)
print("Resultant string: ", resultant_string)
