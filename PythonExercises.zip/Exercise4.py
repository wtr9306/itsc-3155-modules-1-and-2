n = int(input("Enter a number: "))

numbers = []
for i in range(n):
    num = float(input(f"Enter float number {i+1}: "))
    numbers.append(num)

print("The list of numbers:", numbers)
mean = sum(numbers)/n
print("The mean of the numbers:", mean)
